// Main JS for OnlineBookstore
// TODO: Add interactivity and AJAX calls
