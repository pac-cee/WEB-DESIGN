This folder will contain audio book files and related scripts.
