Online Bookstore
----------------
- Home: index.php
- Add Book: add_book.php
- View Books: view_books.php
- Register: register.php
- Login: login.php

Database tables needed:
- books (id, title, author, price)
- users (id, username, password)

Add your own images and content as needed.
